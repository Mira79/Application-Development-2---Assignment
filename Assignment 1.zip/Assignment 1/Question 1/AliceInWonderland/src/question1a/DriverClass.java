package question1a;


import java.util.Random;

public class DriverClass {

	public static void main(String[] args) {
		
		
		Random rand= new Random();
	
		Random a = new Random();
		Random b= new Random();
		Random c= new Random();
		
	
		
System.out.println(a.nextInt(3));

System.out.println( b.nextInt(13));

System.out.println( c.nextInt(67));
	

	}

}
