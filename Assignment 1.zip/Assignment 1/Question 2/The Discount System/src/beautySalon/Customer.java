// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Mira Turk and 2195213)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------

package beautySalon;

public class Customer {
	
	private String name; //ok
	private boolean isMember;
	private String memberType; //ok


	
	public Customer(String name, boolean isMember, String memberType) {
		this.name = name;
		this.isMember = isMember;
		this.memberType = memberType;
	}
	public String getName() { //ok
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isMember() {
		return isMember;
	}
	public void setisMember(boolean isMember) {
		this.isMember = isMember;
	}
	public String getMemberType() { //ok
		return memberType;
	}
	public void setMemberType(String memberType) { //ok
		this.memberType = memberType;
	}

	public String toString() {
		return "Name" + name + "Status  " + isMember + "If Member.  Member Type:  " + memberType + ".";
	}
	
	
}
