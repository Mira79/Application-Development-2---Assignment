// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Mira Turk and 2195213)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------


package beautySalon;

import java.util.Date;



public class Visit {

	private Customer name;
	private Date date;
	

	private double serviceExpense;
	private double productExpense;
	
	
	
	public Customer getname() {
		return name;
	}
	public void setname(Customer name) {
		this.name = name;
	}
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getServiceExpense() {
		return serviceExpense;
	}
	public void setServiceExpense(double serviceExpense) {
		this.serviceExpense = serviceExpense;
	}
	public double getProductExpense() {
		return productExpense;
	}
	public void setProductExpense(double productExpense) {
		this.productExpense = productExpense;
	}
	
	public Visit(Customer name, Date date, double serviceExpense, double productExpense) {
		this.name = name;
		this.date = date;
		this.serviceExpense = serviceExpense;
		this.productExpense = productExpense;
	}
	
	public double getTotalExpense() {
		return (serviceExpense - (serviceExpense * DiscountRate.getServiceDiscountRate(name.getMemberType())))+
			   (productExpense - (productExpense * DiscountRate.getProductDiscountRate(name.getMemberType())));
	}
	
	public String toString() {
		return "Visit:" + name + ", Date=" + date + ", serviceExpense=" + serviceExpense
				+ ", productExpense=" + productExpense + ".";
	}
	
    	

}
