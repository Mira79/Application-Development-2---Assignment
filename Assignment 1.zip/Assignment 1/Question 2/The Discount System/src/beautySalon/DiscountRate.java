// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Mira Turk and 2195213)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------

package beautySalon;


public class DiscountRate{

    private static double serviceDiscountPremium=0.2;
    private static double serviceDiscountGold = 0.15;
    private static double serviceDiscountSilver = 0.1;
    private static double productDiscountPremium = 0.1;
    private static double productDiscountGold = 0.1;
    private static double productDiscountSilver = 0.1;
    static double notAMember = 1;
    

    public static double getServiceDiscountRate(String memberType) {
		
        switch (memberType) {
        case "Premium":
            return serviceDiscountPremium;
        case "Gold":
            return serviceDiscountGold;
        case "Silver":
            return serviceDiscountSilver;
        case "Not a Member":
			return	notAMember;
        default: System.out.println("Wrong entry.");
    }
		return 0;

}


    public static double getProductDiscountRate(String membertype) {
        switch (membertype) {
            case "Premium":
                return productDiscountPremium;
            case "Gold":
                return productDiscountGold;
            case "Silver":
                return productDiscountSilver;
            case "Not a Member":
            	return notAMember;
            default: System.out.println("Wrong entry.");
        }
        return 0;
    }


    


	

}
